/*
* Header file for the DOMWalker program, in which an XML tree is written in memory
* then reproduced by the tree walker.
* This program uses the xerces XML API found here:
* https://xerces.apache.org/xerces-c/
* File:   CreateDomDocument.h
* Author: Alex Cushing
*
* Created on November 18, 2015, 11:17 AM
*/

#ifndef CREATEDOMDOCUMENT_H
#define	CREATEDOMDOCUMENT_H

//
// Include files for xercesc
//
#include <xercesc/sax/ErrorHandler.hpp>
#include <xercesc/util/XercesDefs.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/OutOfMemoryException.hpp>  
#include <xercesc/util/PlatformUtils.hpp>  
#include <xercesc/dom/DOM.hpp>
#include <xercesc/framework/StdOutFormatTarget.hpp>
#include <xercesc/framework/LocalFileFormatTarget.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>  
#include <xercesc/dom/DOMTreeWalker.hpp> 
#include <xercesc/dom/DOMLSSerializer.hpp>
#include <string.h>
#include <string>
#include <stdlib.h>
#include <time.h>

#if defined(XERCES_NEW_IOSTREAMS)
#include <iostream>
#else
#include <iostream.h>
#endif
XERCES_CPP_NAMESPACE_USE

using namespace std;

/**
*  Simple class used to convert from char* data into XMLCh data. Taken from the example
* found at:
* https://xerces.apache.org/xerces-c/createdoc-3.html
*/
class XStr
{
private:
	/**
	* Unicode XMLCh format of the string
	*/
        XMLCh*  fUnicodeForm;
        XMLCh* TAG_root; //got from yolinux.com tutorial


public:

	/**
	* CONSTRUCTOR
	* @param toTransCode - this is the string that gets converted
	* @return - returns converted to xml data
	*/
	XStr(const char* const toTransCode)
	{
		//xerces function for transcoding XML
		fUnicodeForm = XMLString::transcode(toTransCode);
                                    TAG_root        = XMLString::transcode("root");
	}

	/**
	* destructor func
	* properly release fUnicodeForm
	*/
	~XStr()
	{
		XMLString::release(&fUnicodeForm);
	}

	/**
	* unicode returning func
	* @return - returns the unicode form of said XMLCh
	*/
	const XMLCh* unicodeForm() const
	{
                                    //returns fUnicodeForm
		return fUnicodeForm;
	}
        
            

};


/**
* this cuts it down
* XStr class
*/
#define X(str) XStr(str).unicodeForm()


#endif	