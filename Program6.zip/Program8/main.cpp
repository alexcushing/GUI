/*
* Header file for the DOMWalker program, in which an XML tree is written in memory
* then reproduced by the tree walker.
* This program uses the xerces XML API found here:
 * 
* https://xerces.apache.org/xerces-c/
 * 
 * help from James Erardi
 * not really succesful, couldn't get xerces into
 * netbeans for a while and had a really busy week, 
 * but did what I could in time for the solid due date
 * 
* File:   CreateDomDocument.h
* Author: Alex Cushing
*
* Created on November 18, 2015, 11:17 AM
*/


#include "CreateDomDocument.h"
using namespace xercesc;
void createParser();
int main(int argc, char*[])
{
		
    static XercesDOMParser::ValSchemes    gValScheme = XercesDOMParser::Val_Auto;
    XMLPlatformUtils::Initialize();

    DOMImplementation* impl = DOMImplementationRegistry::getDOMImplementation(X("CORE"));
    
    int s=0;
    
    std::cout << "Welcome!"<<endl;
    
	
    DOMDocument* doc = impl->createDocument(
            0,                              
            X("metadata"),           // root element name
            0);                            // document type object
                                         
    
    
    
    
     std::cout << s<<endl;
    DOMElement* rootElem = doc->getDocumentElement();
    rootElem->setAttribute(X("one"), X("juan"));
    rootElem->setAttribute(X("two"),X("true"));
    rootElem->setAttribute(X("three"),X("me"));
    s++;
    std::cout << s<<endl;
    //recording
    DOMElement*  recElem = doc->createElement(X("recording"));
    recElem->setAttribute(X("id"),X("0b146e53-10e3-3a12-9d3d-7ad10e7068b1"));
    rootElem->appendChild(recElem);
    s++;
    std::cout << s<<endl;
    //title
    DOMElement* titleElem = doc->createElement(X("title"));
    titleElem->setTextContent(X("Mykonis"));
    rootElem->appendChild(titleElem);
    s++;
    std::cout << s<<endl;
    //song1
    DOMElement* song1Elem = doc->createElement(X("One"));
    song1Elem->setTextContent(X("Mykonis_Song"));
    rootElem->appendChild(song1Elem);
    song1Elem->setAttribute(X("rating"), X("10/10"));
    song1Elem->setAttribute(X("description"), X("Beat switch"));
    song1Elem->setAttribute(X("song"), X("long"));
    s++;
    std::cout << s<<endl;
    //song2
    DOMElement* song2Elem = doc->createElement(X("Two"));
    song2Elem->setTextContent(X("Tiger Mountain Peasant Song"));
    rootElem->appendChild(song2Elem);
    song2Elem->setAttribute(X("rating"), X("8/10"));
    song2Elem->setAttribute(X("description"), X("Live"));
    song2Elem->setAttribute(X("title"), X("lengthy"));
    s++;
    std::cout << s<<endl;
    //song2 features
    DOMElement* song2Features = doc->createElement(X("location"));
    song2Features->setTextContent(X("crowd, indianapolis"));
    song2Elem->appendChild(song2Features);
    s++;
    std::cout << s<<endl;
    //song3
    DOMElement* song3Elem = doc->createElement(X("Sun Giant"));
    song3Elem->setTextContent(X("Turning to a new album"));
    rootElem->appendChild(song3Elem);
    song3Elem->setAttribute(X("rating"), X("9/10"));
    song3Elem->setAttribute(X("description"), X("title is sun giant"));
    song3Elem->setAttribute(X("tracks"), X("five"));
    s++;
    std::cout << s<<endl;
    //song4
    DOMElement* song4Elem = doc->createElement(X("second on this"));
    song4Elem->setTextContent(X("Drops in the river"));
    rootElem->appendChild(song4Elem);
    song4Elem->setAttribute(X("rating"), X("6/10"));
    song4Elem->setAttribute(X("description"), X("four minutes"));
    song4Elem->setAttribute(X("voices"), X("quiet"));
    s++;  
    std::cout << s<<endl;
    //song4 addition
    DOMElement* song4Features = doc->createElement(X("instruments"));
    song4Features->setTextContent(X("violins"));
    song4Elem->appendChild(song4Features);
    s++;
    std::cout << s<<endl;
    //song5
    DOMElement* song5Elem = doc->createElement(X("Five but three on this album"));
    song5Elem->setTextContent(X("English House"));
    rootElem->appendChild(song5Elem);
    song5Elem->setAttribute(X("rating"), X("6/10"));
    song5Elem->setAttribute(X("description"), X("six out of ten"));
    song5Elem->setAttribute(X("grate"), X("great"));
    s++;
    std::cout << s<<endl;
    //song5 features
    DOMElement* song5Features = doc->createElement(X("musical instruments"));
    song5Features->setTextContent(X("harp"));
    song5Elem->appendChild(song5Features);
    s++;
    std::cout << s<<endl;
    //song6
    DOMElement* song6Elem = doc->createElement(X("Four"));
    song6Elem->setTextContent(X("Mykonis, 2"));
    rootElem->appendChild(song6Elem);
    song6Elem->setAttribute(X("rating"), X("10/10"));
    song6Elem->setAttribute(X("description"), X("best ff song there is"));
    song6Elem->setAttribute(X("beat"), X("switch"));
    s++;
    std::cout << s<<endl;
    //song6 features
    DOMElement* song6Features = doc->createElement(X("musical instruments"));
    song6Features->setTextContent(X("backup singing"));
    song6Elem->appendChild(song6Features);
    
    s++;
    std::cout << s<<endl;
    //song7
    DOMElement* song7Elem = doc->createElement(X("Seven is five"));
    song7Elem->setTextContent(X("Innocent Son"));
    rootElem->appendChild(song7Elem);
    song7Elem->setAttribute(X("rating"), X("9/10"));
    song7Elem->setAttribute(X("description"), X("he was an innocent son"));
    song7Elem->setAttribute(X("Enjoy"), X("life"));
    s++;
    std::cout << s<<endl;
    //song7 features
    DOMElement* song7Features = doc->createElement(X("Features instruments"));
    song7Features->setTextContent(X("LAUGHING"));
    song7Elem->appendChild(song7Features); 
    s++;
    std::cout << s<<endl;
    //song8
    DOMElement* song8Elem = doc->createElement(X("Eight"));
    song8Elem->setTextContent(X("Montezuma"));
    rootElem->appendChild(song8Elem);
    song8Elem->setAttribute(X("rating"), X("9/10"));
    song8Elem->setAttribute(X("description"), X("great song"));
    song8Elem->setAttribute(X("fan"), X("tastic"));
    s++;
    std::cout << s<<endl;
    //song features
    DOMElement* song8Features = doc->createElement(X("Features instruments"));
    song8Features->setTextContent(X("microphone"));
    song8Elem->appendChild(song8Features); 
    s++;
    std::cout << s<<endl;
    //song9
    DOMElement* song9Elem = doc->createElement(X("Nine"));
    song9Elem->setTextContent(X("Bedouin Dress"));
    rootElem->appendChild(song9Elem);
    song9Elem->setAttribute(X("rating"), X("9/10"));
    song9Elem->setAttribute(X("description"), X("Cool dress"));
    song9Elem->setAttribute(X("love"), X("music"));
s++;
std::cout << s<<endl;
    //song10
    DOMElement* song10Elem = doc->createElement(X("Ten"));
    song10Elem->setTextContent(X("Sim Sala Bim"));
    rootElem->appendChild(song10Elem);
    song10Elem->setAttribute(X("rating"), X("3/10"));
    song10Elem->setAttribute(X("description"), X("confused"));
    song10Elem->setAttribute(X("color"), X("green"));
    s++;
    std::cout << s<<endl;
    //song11
    DOMElement* song11Elem = doc->createElement(X("Eleven"));
    song11Elem->setTextContent(X("Battery Kinzie"));
    rootElem->appendChild(song11Elem);
    song11Elem->setAttribute(X("rating"), X("7/10"));
    song11Elem->setAttribute(X("description"), X("batteries are good"));
    song11Elem->setAttribute(X("twinkle"), X("star"));
    s++;
    std::cout << s<<endl;
       //song12
    DOMElement* song12Elem = doc->createElement(X("Twelve"));
    song12Elem->setTextContent(X("The Plains Bitter Dancer"));
    rootElem->appendChild(song12Elem);
    song12Elem->setAttribute(X("rating"), X("7/10"));
    song12Elem->setAttribute(X("description"), X("dancing"));
    song12Elem->setAttribute(X("dancing"), X("nancies"));
    s++;
    std::cout << s<<endl;
         //song13
    DOMElement* song13Elem = doc->createElement(X("Thirteen"));
    song13Elem->setTextContent(X("The Cascades"));
    rootElem->appendChild(song13Elem);
    song13Elem->setAttribute(X("rating"), X("8/10"));
    song13Elem->setAttribute(X("description"), X("cascades are coool"));
    song13Elem->setAttribute(X("mountains"), X("fields"));
    s++;
    std::cout << s<<endl;
             //song14
    DOMElement* song14Elem = doc->createElement(X("Fourteen"));
    song14Elem->setTextContent(X("Lorelai"));
    rootElem->appendChild(song14Elem);
    song14Elem->setAttribute(X("rating"), X("9/10"));
    song14Elem->setAttribute(X("description"), X("girls name"));
    song14Elem->setAttribute(X("missus"), X("lorelai"));
    s++;
    std::cout << s<<endl;
    std::cout<<endl<<"Your XML file has "<<s<<" elements in it." << endl;
    
    
const XMLSize_t elementCount = doc->getElementsByTagName(X("*"))->getLength();
XERCES_STD_QUALIFIER cout << "The tree just created contains: " << elementCount << " elements." << XERCES_STD_QUALIFIER endl;



/**
 * 
 * this is supposed to go through and print out the XML
 */





    string value;
    
    if (doc) {
        for(int i=0; i<elementCount; i++){

        XERCES_STD_QUALIFIER cout << doc->getElementsByTagName(X("*"))->item(i) << XERCES_STD_QUALIFIER endl;
        }
    }
 //release the XML document    
//doc->release(); 

DOMLSSerializer *serializer = ((DOMImplementationLS*)impl)->createLSSerializer();
serializer->setNewLine(X("\n"));
    
    if(serializer->getDomConfig()->canSetParameter(XMLUni::fgDOMWRTFormatPrettyPrint, true)){
        
        serializer->getDomConfig()->setParameter(XMLUni::fgDOMWRTFormatPrettyPrint, true);
        
    }
 
    DOMLSOutput* outputDesc = ((DOMImplementationLS*)impl)->createLSOutput();
    
    
   XMLFormatTarget *myFormTarget = new StdOutFormatTarget();
   
   outputDesc->setByteStream(myFormTarget);
    
    serializer->write(doc, outputDesc);
    outputDesc->release();
    serializer->release();
    doc->release(); 

}


/*
 *creates a dom parser
 */
void createParser()
{
    XercesDOMParser*   parser = NULL;
}
/*
 *class for dom document parsing
 * LOTS of help from http://vichargrave.com/ for this class
 */
class XmlDomDocument
{
    DOMDocument* m_doc;
 
  public:
      /*
       *constructor
       */
        XmlDomDocument(const char* xmlfile){
            {
                
            XercesDOMParser* parser = NULL;
            parser->parse(xmlfile);
            }
        }
        /*
       *destructor
       */
        ~XmlDomDocument(){
            {
            if (m_doc){ 
                m_doc->release();
            }
        }
    }
        /*
       *gets value of the child
         * *parentTag-tag of the parent in XML
         * parentindex-that parents index
         * childTag-tag of that parent's child
         * childIndex-the index of the child element in XML
         * returns stringg of the value , the childs value
         * 
       */
    string getChildValue(const char* parentTag, int parentIndex,  const char* childTag, int childIndex){
        
        {
            XMLCh* temp = XMLString::transcode(parentTag);
            DOMNodeList* list = m_doc->getElementsByTagName(temp);
            XMLString::release(&temp);

            DOMElement* parent = 
                dynamic_cast<DOMElement*>(list->item(parentIndex));
            DOMElement* child = 
                dynamic_cast<DOMElement*>(parent->getElementsByTagName(
                    XMLString::transcode(childTag))->item(childIndex));

            string value;
            if (child) {
                char* temp2 = XMLString::transcode(child->getTextContent());
                value = temp2;
                XMLString::release(&temp2);
            }
            else {
                value = "";
            }
            return value;
}
        
        /*
       *count of children
         * parentTag-tag of the parent in XML
         * parentindex-that parents index
         * childTag-tag of that parent's child
         * returns an int value of length
       */
    }
    int getChildCount(const char* parentTag, int parentIndex, const char* childTag){
        {
            XMLCh* temp = XMLString::transcode(parentTag);
            DOMNodeList* list = m_doc->getElementsByTagName(temp);
            XMLString::release(&temp);

            DOMElement* parent = dynamic_cast<DOMElement*>(list->item(parentIndex));
            DOMNodeList* childList = parent->getElementsByTagName(XMLString::transcode(childTag));
            return (int)childList->getLength();
        }
    }
 
  private:
    XmlDomDocument();
};